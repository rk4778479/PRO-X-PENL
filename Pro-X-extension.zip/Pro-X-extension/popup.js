"use strict";

/*
 * Pro X popup
 * Safe local dashboard navigation and payout draft storage.
 */

const $ = (id) => document.getElementById(id);

const PAGE_TITLES = {
  facebook: "Connect FB Account",
  transfer: "Transfer All Sources / Monetization",
  payout: "Create Payout and Attach",
  banking: "Banking & Tax",
  history: "History",
  credits: "Credits",
  "admin-tools": "Admin Tools",
  admin: "Admin Panel"
};


/* =========================================================
   PAGE NAVIGATION
   ========================================================= */

function showPage(pageName) {

  document
    .querySelectorAll(".page")
    .forEach((page) => {
      page.classList.remove("active");
    });

  document
    .querySelectorAll("[data-page]")
    .forEach((item) => {
      item.classList.remove("active");
    });

  const page = $(`page-${pageName}`);

  if (page) {
    page.classList.add("active");
  }

  const navItem = document.querySelector(
    `[data-page="${CSS.escape(pageName)}"]`
  );

  if (navItem) {
    navItem.classList.add("active");
  }

  const title = $("topbarTitle");

  if (title) {
    title.textContent =
      PAGE_TITLES[pageName] || "Pro X";
  }

  chrome.storage.local
    .set({
      activeDashboardPage: pageName
    })
    .catch(() => {});
}


/* =========================================================
   LOAD LAST PAGE
   ========================================================= */

async function loadLastPage() {

  try {

    const result =
      await chrome.storage.local.get([
        "activeDashboardPage"
      ]);

    const pageName =
      result.activeDashboardPage || "facebook";

    if ($(`page-${pageName}`)) {

      showPage(pageName);

    } else {

      showPage("facebook");

    }

  } catch (error) {

    console.error(
      "Could not load last page:",
      error
    );

    showPage("facebook");
  }
}


/* =========================================================
   SIDEBAR
   ========================================================= */

function wireSidebar() {

  document
    .querySelectorAll("[data-page]")
    .forEach((item) => {

      item.addEventListener(
        "click",
        () => {

          const pageName =
            item.dataset.page;

          if (!pageName) {
            return;
          }

          showPage(pageName);

        }
      );

    });
}


/* =========================================================
   PAYOUT FORM
   ========================================================= */

function getFormData() {

  const ids = [
    "firstName",
    "lastName",
    "dob",
    "country",
    "payoutSubtype",
    "email",
    "phone",
    "street1",
    "street2",
    "city",
    "state",
    "zip",
    "taxId",
    "taxType"
  ];

  const data = {};

  ids.forEach((id) => {

    const element = $(id);

    if (element) {
      data[id] = element.value || "";
    }

  });

  const randomAll =
    $("randomAll");

  const randomCountry =
    $("randomCountry");

  data.randomAll =
    randomAll
      ? randomAll.checked
      : false;

  data.randomCountry =
    randomCountry
      ? randomCountry.checked
      : false;

  return data;
}


function applyFormData(data) {

  if (!data) {
    return;
  }

  Object.entries(data).forEach(
    ([key, value]) => {

      const element = $(key);

      if (!element) {
        return;
      }

      if (
        element.type === "checkbox"
      ) {

        element.checked =
          Boolean(value);

      } else {

        element.value =
          value === null ||
          value === undefined
            ? ""
            : value;

      }

    }
  );
}


async function loadDraft() {

  try {

    const result =
      await chrome.storage.local.get([
        "payoutDraft"
      ]);

    if (result.payoutDraft) {

      applyFormData(
        result.payoutDraft
      );

    }

  } catch (error) {

    console.error(
      "Could not load payout draft:",
      error
    );

  }
}


function setFormStatus(
  message,
  type
) {

  const status =
    $("formStatus");

  if (!status) {
    return;
  }

  status.className =
    "status" +
    (type
      ? ` ${type}`
      : "");

  status.textContent =
    message || "";
}


async function saveDraft() {

  try {

    await chrome.storage.local.set({
      payoutDraft:
        getFormData()
    });

    setFormStatus(
      "Draft saved locally.",
      "ok"
    );

  } catch (error) {

    console.error(error);

    setFormStatus(
      "Could not save draft.",
      "err"
    );

  }
}


async function clearForm() {

  const form =
    $("payoutForm");

  if (form) {
    form.reset();
  }

  try {

    await chrome.storage.local.remove([
      "payoutDraft"
    ]);

    setFormStatus(
      "Form cleared.",
      "ok"
    );

  } catch (error) {

    console.error(error);

    setFormStatus(
      "Could not clear form.",
      "err"
    );

  }
}


async function copyAccountData() {

  const data =
    getFormData();

  try {

    await navigator.clipboard.writeText(
      JSON.stringify(
        data,
        null,
        2
      )
    );

    setFormStatus(
      "Account data copied.",
      "ok"
    );

  } catch (error) {

    console.error(error);

    setFormStatus(
      "Copy failed.",
      "err"
    );

  }
}


/* =========================================================
   TRANSFER UI
   ========================================================= */

function wireTransfer() {

  const button =
    $("runTransfer");

  if (!button) {
    return;
  }

  button.addEventListener(
    "click",
    () => {

      const status =
        $("transferStatus");

      if (!status) {
        return;
      }

      status.className =
        "status ok";

      status.textContent =
        "Operation selected. No external account action was performed.";

    }
  );
}


/* =========================================================
   FACEBOOK PAGE
   ========================================================= */

function wireFacebookPage() {

  const openButton =
    $("openPairing");

  if (openButton) {

    openButton.addEventListener(
      "click",
      () => {

        const status =
          $("facebookStatus");

        if (status) {

          status.className =
            "status ok";

          status.textContent =
            "Pairing workflow is available through your configured extension workflow.";

        }

      }
    );

  }


  const refreshButton =
    $("refreshPairing");

  if (refreshButton) {

    refreshButton.addEventListener(
      "click",
      () => {

        const status =
          $("pairingStatus");

        if (status) {

          status.className =
            "status ok";

          status.textContent =
            "Pairing status refreshed.";

        }

      }
    );

  }

}


/* =========================================================
   RANDOM OPTIONS
   ========================================================= */

function wireRandomOptions() {

  const randomAll =
    $("randomAll");

  const randomCountry =
    $("randomCountry");

  if (randomAll) {

    randomAll.addEventListener(
      "change",
      () => {

        if (
          randomAll.checked &&
          randomCountry
        ) {

          randomCountry.checked =
            false;

        }

      }
    );

  }


  if (randomCountry) {

    randomCountry.addEventListener(
      "change",
      () => {

        if (
          randomCountry.checked &&
          randomAll
        ) {

          randomAll.checked =
            false;

        }

      }
    );

  }

}


/* =========================================================
   BUTTONS
   ========================================================= */

function wireButtons() {

  const save =
    $("saveDraft");

  if (save) {

    save.addEventListener(
      "click",
      saveDraft
    );

  }


  const clear =
    $("clearForm");

  if (clear) {

    clear.addEventListener(
      "click",
      clearForm
    );

  }


  const exportButton =
    $("exportForm");

  if (exportButton) {

    exportButton.addEventListener(
      "click",
      copyAccountData
    );

  }

}


/* =========================================================
   START
   ========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  async () => {

    wireSidebar();

    wireButtons();

    wireTransfer();

    wireFacebookPage();

    wireRandomOptions();

    await loadDraft();

    await loadLastPage();

  }
);