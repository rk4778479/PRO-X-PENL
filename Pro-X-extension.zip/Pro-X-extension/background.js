"use strict";

// Pro X background service worker
// Handles extension-local storage and opens the existing
// Pro X popup page as a full browser tab.

async function getLatestData() {
  const data = await chrome.storage.local.get([
    "latestCurl",
    "capturedAt",
    "capturedHost",
    "captureMeta"
  ]);

  return {
    latestCurl: data.latestCurl ?? null,
    capturedAt: data.capturedAt ?? null,
    capturedHost: data.capturedHost ?? null,
    captureMeta: data.captureMeta ?? null
  };
}


async function clearLatestData() {
  await chrome.storage.local.remove([
    "latestCurl",
    "capturedAt",
    "capturedHost",
    "captureMeta"
  ]);

  return {
    ok: true
  };
}


/* =========================================================
   TOOLBAR ICON
   Opens the EXISTING popup.html as a full browser tab.
   ========================================================= */

chrome.action.onClicked.addListener(() => {

  chrome.tabs.create({
    url: chrome.runtime.getURL("popup.html")
  });

});


/* =========================================================
   EXTENSION MESSAGES
   ========================================================= */

chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {

    if (
      !message ||
      typeof message.type !== "string"
    ) {

      sendResponse({
        ok: false,
        error: "Invalid message."
      });

      return;

    }


    /* -----------------------------------------------
       GET LATEST STORED DATA
       ----------------------------------------------- */

    if (message.type === "get-latest-curl") {

      getLatestData()
        .then((data) => {

          sendResponse({
            ok: true,
            ...data
          });

        })
        .catch((error) => {

          console.error(
            "Pro X:",
            error
          );

          sendResponse({
            ok: false,
            latestCurl: null,
            capturedAt: null,
            capturedHost: null,
            captureMeta: null,
            error: "Could not read stored data."
          });

        });

      return true;
    }


    /* -----------------------------------------------
       CLEAR LATEST STORED DATA
       ----------------------------------------------- */

    if (message.type === "clear-latest-curl") {

      clearLatestData()
        .then((result) => {

          sendResponse(result);

        })
        .catch((error) => {

          console.error(
            "Pro X:",
            error
          );

          sendResponse({
            ok: false,
            error: "Could not clear stored data."
          });

        });

      return true;
    }


    /* -----------------------------------------------
       UNKNOWN MESSAGE
       ----------------------------------------------- */

    sendResponse({
      ok: false,
      error: "Unknown message type."
    });

  }
);


console.log(
  "Pro X background service worker loaded."
);