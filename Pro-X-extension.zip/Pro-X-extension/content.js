/* Injected into every page. Lets the SocialProX dashboard talk to the
 * extension over window.postMessage:
 *   SOCIAL_HUB_CHECK     -> SOCIAL_HUB_PRESENT { version }
 *   SOCIAL_HUB_GET_CURL  -> SOCIAL_HUB_CURL_RESULT { ok, curl, capturedAt, capturedHost, meta, error? }
 */

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (typeof msg?.type !== "string" || !msg.type.startsWith("SOCIAL_HUB_")) return;

  if (msg.type === "SOCIAL_HUB_CHECK") {
    const { version } = chrome.runtime.getManifest();
    window.postMessage({ type: "SOCIAL_HUB_PRESENT", version }, "*");
    return;
  }

  if (msg.type === "SOCIAL_HUB_GET_CURL") {
    chrome.runtime.sendMessage({ type: "get-latest-curl" }, (res) => {
      const result = res ?? {};
      const curl = typeof result.latestCurl === "string" ? result.latestCurl : null;
      window.postMessage(
        {
          type: "SOCIAL_HUB_CURL_RESULT",
          ok: !!curl,
          curl,
          capturedAt: result.capturedAt ?? null,
          capturedHost: result.capturedHost ?? null,
          meta: result.captureMeta ?? null,
          error: curl ? null : "No GraphQL POST captured yet. Open facebook.com and click around once.",
        },
        "*",
      );
    });
  }
});
